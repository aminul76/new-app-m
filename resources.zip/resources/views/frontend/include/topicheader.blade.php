<div class="topic-header">
    <button class="back-button">
      <span>&#x2190;</span> <!-- Left arrow for back -->
    </button>
    <h2 class="topic-title">নাম বিষয় শিরোনাম</h2>
    <button class="more-options-button">
      <span>&#x22ee;</span> <!-- Three vertical dots for more options -->
    </button>
  </div>

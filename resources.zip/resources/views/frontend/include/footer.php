<footer>
        <div class="footer-icons">
            <a href="index.html">
                <i class="fas fa-home"></i>
                <span class="footer-text">Home</span>
            </a>
            <a href="routine.html">
                <i class="fas fa-calendar-check"></i>
                <span class="footer-text">Routine</span>
            </a>
            <a href="result.html">
                <i class="fas fa-chart-line"></i>
                <span class="footer-text">Results</span>
            </a>
            <a href="profile.html">
                <i class="fas fa-user"></i>
                <span class="footer-text">Profile</span>
            </a>

        </div>
    </footer>

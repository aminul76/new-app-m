@extends('backend.master')

@section('content')
    <h1>Courses List</h1>
    <a href="{{ route('admin.courses.create') }}">Create New Course</a>
    @if ($message = Session::get('success'))
        <p>{{ $message }}</p>
    @endif
    <table id="dTable" class="display">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Slug</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($courses as $course)
                <tr>
                    <td>{{ $course->id }}</td>
                    <td>{{ $course->c_title }}</td>
                    <td>{{ $course->c_slug }}</td>
                    <td>
                        <a href="{{ route('admin.courses.edit', $course->id) }}">Edit</a>
                        <form action="{{ route('admin.courses.destroy', $course->id) }}" method="POST" style="display:inline;"onsubmit="return confirmDelete();">
                        @csrf
                        @method('DELETE')
                        <button type="submit">Delete</button>
                    </form>

                    <script>
                    function confirmDelete() {
                        return confirm('Are you sure you want to delete this course?');
                    }
                    </script>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
